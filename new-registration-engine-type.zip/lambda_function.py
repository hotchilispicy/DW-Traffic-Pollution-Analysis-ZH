import urllib.request
import boto3

# Set the S3 bucket and folder (if applicable)
S3_BUCKET_NAME = "zurich-registration-engine-type"
S3_FOLDER = ""  

def download_and_upload_file(resource_url, file_name):
    """
    Download a file from a URL and upload it to an S3 bucket.
    """
    try:
        with urllib.request.urlopen(resource_url) as response:
            file_data = response.read()
            s3 = boto3.client("s3")
            s3_key = f"{S3_FOLDER}/{file_name}" if S3_FOLDER else file_name
            s3.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=s3_key,
                Body=file_data
            )
            return f"Uploaded {file_name} to S3 bucket {S3_BUCKET_NAME}/{S3_FOLDER}"
    except Exception as e:
        return f"Error: {str(e)}"

def lambda_handler(event, context):
    """
    Lambda function to handle the download and upload process.
    """
    # URL of the file to be downloaded
    file_url = "https://data.stadt-zuerich.ch/dataset/prd_ssz_fz_pw_neuzulassungen_jahr_quartier_antriebsart_rechtsform_od2004"
    file_name = "VER2000D2004.csv"  # The name under which you want to save the file in S3

    result = download_and_upload_file(file_url, file_name)
    return {
        'statusCode': 200,
        'body': result
    }

import json
import urllib.request
import boto3

# S3 Configuration
S3_BUCKET_NAME = "zurich-health-hospital"
S3_FOLDER = ""  # Ensure this is properly formatted if used

def lambda_handler(event, context):
    # Base URL and filename pattern
    base_url = "https://www.zh.ch/de/gesundheit/spitaeler-kliniken/zahlen-fakten-spitaeler.html"
    years = range(2012, 2024)  # From 2012 to 2023

    try:
        for year in years:
            file_url = f"{base_url}/kenndaten_{year}_akutsomatik.xlsx"
            file_name = f"kenndaten_{year}_akutsomatik.xlsx"
            print(f"Attempting to download and upload {file_name}")
            print(f"Constructed URL: {file_url}")

            if download_and_upload_file(file_url, file_name):
                print(f"Successfully processed {file_name}")
            else:
                print(f"Failed to download or upload {file_name}")

        return {"statusCode": 200, "body": json.dumps("Process completed successfully.")}

    except Exception as e:
        print(f"Unhandled exception: {str(e)}")
        return {"statusCode": 500, "body": json.dumps(str(e))}

def download_and_upload_file(file_url, file_name):
    try:
        s3 = boto3.client("s3")
        request = urllib.request.Request(file_url)

        with urllib.request.urlopen(request) as response:
            if response.status == 200:
                file_data = response.read()
                print(f"Uploading {file_name} to bucket {S3_BUCKET_NAME} at {S3_FOLDER}{file_name}")
                s3.put_object(Bucket=S3_BUCKET_NAME, Key=f"{S3_FOLDER}{file_name}", Body=file_data)
                return True
            else:
                print(f"Failed to download {file_name}: HTTP Status {response.status}")
                return False

    except Exception as e:
        print(f"Error downloading or uploading file {file_name}: {str(e)}")
        return False

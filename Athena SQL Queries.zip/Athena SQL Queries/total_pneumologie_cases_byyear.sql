SELECT 
    "labels_all",
    SUM(COALESCE(CAST("universitasspital zurich" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("kantonsspital winterthur" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("stadtspital triemli" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("klinik hirslanden" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("see-spital standort horgen" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("see-spital standort kilchberg" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("spital uster" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("spital limmattal" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("spital bulach" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("spital zollikerberg" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("gzo ag spital wetzikon" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("stadtspital waid" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("schulthess klinik" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("kinderspital zurich" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("spital manedorf" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("universitatsklinik balgrist" AS BIGINT), 0)) +
    SUM(COALESCE(CAST("spital affoltern" AS BIGINT), 0)) +
    SUM(COALESCE("paracelsus-spital richterswil", 0)) +
    SUM(COALESCE("limmatklinik", 0)) +
    SUM(COALESCE("klinik lengg", 0)) +
    SUM(COALESCE("uroviva klinik fur urologie", 0)) +
    SUM(COALESCE("adus medica", 0)) +
    SUM(COALESCE("klinik susenberg", 0)) +
    SUM(COALESCE("sune-egge", 0)) +
    SUM(COALESCE(CAST("klinik im park" AS BIGINT), 0)) +
    SUM(COALESCE("privatklinik bethanien", 0)) +
    SUM(COALESCE(CAST("klinik pyramide am see" AS BIGINT), 0)) +
    SUM(COALESCE("klinik pyramide schwerzenbach", 0)) +
    SUM(COALESCE("klinik lindberg", 0)) +
    SUM(COALESCE("klinik tiefenbrunnen", 0)) +
    SUM(COALESCE("eulachklinik", 0)) +
    SUM(COALESCE("schweizerisches epilepsie-zentrum", 0))
    AS "Total_Pneumologie_Cases"
FROM "zurich-health-hospital-database"."zurich_health_hospital"
WHERE "service sector" = 'Pneumologie'
GROUP BY "labels_all"
ORDER BY "labels_all";

SELECT "inventory year", SUM("number of vehicles") AS total_vehicles
FROM "zurich-registration-database"."zurich_registration_engine_type"
GROUP BY "inventory year"
ORDER BY "inventory year";

WITH YearlyTotals AS (
    SELECT 
        "inventory year", 
        SUM("number of vehicles") AS total_vehicles
    FROM 
        "zurich-fleetsize-database"."zurich_fleetsize_engine_type"
    GROUP BY 
        "inventory year"
),
FuelTypeBreakdown AS (
    SELECT 
        "inventory year", 
        "code for aggregated type of fuel", 
        SUM("number of vehicles") AS total_vehicles
    FROM 
        "zurich-fleetsize-database"."zurich_fleetsize_engine_type"
    GROUP BY 
        "inventory year", 
        "code for aggregated type of fuel"
)
SELECT 
    a."inventory year",
    a.total_vehicles AS "Total Vehicles for Year",
    b."code for aggregated type of fuel",
    b.total_vehicles AS "Total by Fuel Type"
FROM 
    YearlyTotals a
JOIN 
    FuelTypeBreakdown b ON a."inventory year" = b."inventory year"
ORDER BY 
    a."inventory year", 
    b."code for aggregated type of fuel";

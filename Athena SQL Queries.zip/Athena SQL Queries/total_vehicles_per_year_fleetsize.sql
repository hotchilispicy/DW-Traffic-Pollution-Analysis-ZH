SELECT "inventory year", SUM("number of vehicles") AS total_vehicles
FROM "zurich-fleetsize-database"."zurich_fleetsize_engine_type"
GROUP BY "inventory year"
ORDER BY "inventory year";

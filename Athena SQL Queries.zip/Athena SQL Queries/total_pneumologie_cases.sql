SELECT 
    SUM(COALESCE(CAST(NULLIF("universitasspital zurich", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("kantonsspital winterthur", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("stadtspital triemli", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("klinik hirslanden", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("see-spital standort horgen", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("see-spital standort kilchberg", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("spital uster", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("spital limmattal", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("spital bulach", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("spital zollikerberg", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("gzo ag spital wetzikon", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("stadtspital waid", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("schulthess klinik", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("kinderspital zurich", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("spital manedorf", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("universitatsklinik balgrist", '') AS BIGINT), 0)) +
    SUM(COALESCE(CAST(NULLIF("spital affoltern", '') AS BIGINT), 0)) +
    SUM(COALESCE("paracelsus-spital richterswil", 0)) +
    SUM(COALESCE("limmatklinik", 0)) +
    SUM(COALESCE("klinik lengg", 0)) +
    SUM(COALESCE("uroviva klinik fur urologie", 0)) +
    SUM(COALESCE("adus medica", 0)) +
    SUM(COALESCE("klinik susenberg", 0)) +
    SUM(COALESCE("sune-egge", 0)) +
    SUM(COALESCE(CAST(NULLIF("klinik im park", '') AS BIGINT), 0)) +
    SUM(COALESCE("privatklinik bethanien", 0)) +
    SUM(COALESCE(CAST(NULLIF("klinik pyramide am see", '') AS BIGINT), 0)) +
    SUM(COALESCE("klinik pyramide schwerzenbach", 0)) +
    SUM(COALESCE("klinik lindberg", 0)) +
    SUM(COALESCE("klinik tiefenbrunnen", 0)) +
    SUM(COALESCE("eulachklinik", 0)) +
    SUM(COALESCE("schweizerisches epilepsie-zentrum", 0))
AS "Total_Pneumologie_Cases"
FROM "zurich-health-hospital-database"."zurich_health_hospital"
WHERE "service sector" = 'Pneumologie';

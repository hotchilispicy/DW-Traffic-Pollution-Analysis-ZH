SELECT "inventory year", "code for aggregated type of fuel", SUM("number of vehicles") AS total_vehicles
FROM "zurich-registration-database"."zurich_registration_engine_type"
GROUP BY "inventory year", "code for aggregated type of fuel"
ORDER BY "inventory year", "code for aggregated type of fuel";

WITH combined_results AS (
    SELECT 
        "inventory year",
        "city circle code",
        "code for aggregated type of fuel",
        "number of vehicles",
        'FleetSize' AS source
    FROM 
        "zurich-fleetsize-database"."zurich_fleetsize_engine_type"

    UNION ALL

    SELECT 
        "inventory year",
        "city circle code",
        "code for aggregated type of fuel",
        "number of vehicles",
        'Registration' AS source
    FROM 
        "zurich-registration-database"."zurich_registration_engine_type"
)

-- Query to select and aggregate data from the combined results
SELECT
    "inventory year",
    "city circle code",
    "code for aggregated type of fuel",
    SUM(CASE WHEN source = 'FleetSize' THEN "number of vehicles" ELSE 0 END) AS fleet_vehicles,
    SUM(CASE WHEN source = 'Registration' THEN "number of vehicles" ELSE 0 END) AS registered_vehicles,
    SUM("number of vehicles") AS total_vehicles
FROM 
    combined_results
GROUP BY 
    "inventory year",
    "city circle code",
    "code for aggregated type of fuel"
ORDER BY 
    "inventory year",
    "city circle code",
    "code for aggregated type of fuel";
